import asyncio
import json
import ssl
import threading
import websocket
import certifi
from typing import Any, Callable, Dict, Optional, List
from enum import Enum
from dataclasses import dataclass


class GpioStatus(Enum):
    """GPIO pin status values"""
    HIGH = "high"
    LOW = "low"


@dataclass
class Gpio:
    """GPIO message with status information"""
    status: GpioStatus


class PhobosGPIOInterfaceAPIClient:
    """
    AsyncAPI WebSocket Client for Phobos GPIO interface API
    WebSocket API for bidirectional GPIO messages between client and server
    """
    
    def __init__(self, server_url: str = "wss://127.0.0.1"):
        self.url = server_url
        self.ws = None
        self.message_handlers: Dict[str, List[Callable]] = {}
        self.error_handlers: List[Callable] = []
        self.connected = False
        self._thread = None
        
    def connect(self) -> bool:
        """Connect to the WebSocket server"""
        try:
            # SSL context for secure connections
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            
            self.ws = websocket.WebSocketApp(
                self.url,
                on_open=self._on_open,
                on_message=self._on_message,
                on_error=self._on_error,
                on_close=self._on_close
            )
            
            # Run in separate thread
            self._thread = threading.Thread(
                target=self.ws.run_forever,
                kwargs={"sslopt": {"cert_reqs": ssl.CERT_NONE}}
            )
            self._thread.daemon = True
            self._thread.start()
            
            # Wait a moment for connection
            import time
            time.sleep(1)
            return self.connected
            
        except Exception as e:
            print(f"Connection error: {e}")
            return False
    
    def disconnect(self):
        """Disconnect from the WebSocket server"""
        if self.ws:
            self.ws.close()
        self.connected = False
    
    def _on_open(self, ws):
        """Called when WebSocket connection is opened"""
        self.connected = True
        print("Connected to WebSocket server")
    
    def _on_close(self, ws, close_status_code, close_msg):
        """Called when WebSocket connection is closed"""
        self.connected = False
        print("Disconnected from WebSocket server")
    
    def _on_error(self, ws, error):
        """Called when WebSocket error occurs"""
        print(f"WebSocket error: {error}")
        for handler in self.error_handlers:
            try:
                handler(error)
            except Exception as e:
                print(f"Error handler failed: {e}")
    
    def _on_message(self, ws, message):
        """Called when a message is received"""
        try:
            data = json.loads(message)
            message_type = data.get('type', 'GpioMessage')
            
            if message_type in self.message_handlers:
                for handler in self.message_handlers[message_type]:
                    try:
                        handler(data)
                    except Exception as e:
                        print(f"Message handler error: {e}")
        except json.JSONDecodeError as e:
            print(f"Failed to decode message: {e}")
    
    def register_message_handler(self, message_type: str, handler: Callable[[Dict], None]):
        """Register a handler for specific message types"""
        if message_type not in self.message_handlers:
            self.message_handlers[message_type] = []
        self.message_handlers[message_type].append(handler)
    
    def register_error_handler(self, handler: Callable[[Exception], None]):
        """Register an error handler"""
        self.error_handlers.append(handler)
    
    def send_message(self, data: Dict[str, Any]) -> bool:
        """Send a message to the server"""
        if not self.connected or not self.ws:
            print("Not connected to server")
            return False
        
        try:
            message = json.dumps(data)
            self.ws.send(message)
            return True
        except Exception as e:
            print(f"Failed to send message: {e}")
            return False

    def send_gpio_message(self, gpio_data: Dict[str, Any]) -> bool:
        """Send GpioMessage message"""
        message_data = {
            "type": "GpioMessage",
            "payload": gpio_data
        }
        return self.send_message(message_data)
    
    def on_gpio_message(self, handler: Callable[[Dict], None]):
        """Register handler for GpioMessage messages"""
        self.register_message_handler("GpioMessage", handler)


# Example usage
if __name__ == "__main__":
    client = PhobosGPIOInterfaceAPIClient()
    
    def handle_gpio_message(data):
        print(f"Received GPIO message: {data}")
    
    client.on_gpio_message(handle_gpio_message)
    
    if client.connect():
        print("Connected successfully!")
        
        # Send a test message
        client.send_gpio_message({"status": "high"})
        
        # Keep alive
        import time
        time.sleep(5)
        
        client.disconnect()
    else:
        print("Failed to connect")