# Phobos GPIO Interface API Python Client (Offline Version)

This is a standalone Python WebSocket client generated from AsyncAPI 3.0.0 specification that works completely offline.

## Installation

```bash
pip install -r requirements.txt
```

## Usage

```python
from client import PhobosGPIOInterfaceAPIClient

# Create client instance
client = PhobosGPIOInterfaceAPIClient("wss://127.0.0.1")

# Register message handler
def handle_gpio_message(data):
    print(f"Received GPIO message: {data}")

client.on_gpio_message(handle_gpio_message)

# Connect to server
if client.connect():
    print("Connected successfully!")
    
    # Send GPIO message
    client.send_gpio_message({"status": "high"})
    
    # Keep connection alive
    import time
    time.sleep(10)
    
    # Disconnect
    client.disconnect()
else:
    print("Failed to connect")
```

## Features

- ✅ **Completely offline** - No network dependencies for generation
- ✅ **AsyncAPI 3.0.0 compatible** - Based on your AsyncAPI specification
- ✅ **WebSocket support** - SSL/WSS and WS protocols
- ✅ **Type safety** - Enums and dataclasses for GPIO messages
- ✅ **Error handling** - Built-in error handlers
- ✅ **Threading** - Non-blocking WebSocket operations

## API Reference

### PhobosGPIOInterfaceAPIClient

#### Methods:
- `connect()` - Connect to WebSocket server
- `disconnect()` - Disconnect from server
- `send_gpio_message(data)` - Send GPIO message
- `on_gpio_message(handler)` - Register GPIO message handler
- `register_error_handler(handler)` - Register error handler

#### Data Types:
- `GpioStatus.HIGH` = "high"
- `GpioStatus.LOW` = "low"
- `Gpio` - Dataclass with status field